---
title: Titulo
subtitle: Subtitulo
author:
  - name: nombre
    affiliation: empresa
    location: lugar
    email: correo electronico
numbersections: yes
lang: es
abstract: |
    aqui va el resumen
header-includes: |
  \usepackage{booktabs}
...

---

**Super** articulo  sobre
[inteligencia artificial](https://www.tandfonline.com/doi/pdf/10.1207/s15326985ep2403_2).


[@winne1989theories] escribio sobre `inteligencia artificial`.

![[inteligencia artificial](https://www.google.com/url?sa=i&url=https%3A%2F%2Fcomputerhoy.com%2Freportajes%2Ftecnologia%2Finteligencia-artificial-469917&psig=AOvVaw0fyB9uKxqu5KBnNXE9T5GX&ust=1592620065032000&source=images&cd=vfe&ved=0CAIQjRxqFwoTCNiJ0ZzqjOoCFQAAAAAdAAAAABAD)](inteligencia-artificial.jpg){#fig:cat}

# I References


---
nocite: '@*'
---


